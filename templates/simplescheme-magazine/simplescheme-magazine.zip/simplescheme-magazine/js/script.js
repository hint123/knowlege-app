$(function() {
	$('#featured').cycle({
		fx: 'scrollLeft',
		speed: 700,
		timeout: 5000
	});
});
